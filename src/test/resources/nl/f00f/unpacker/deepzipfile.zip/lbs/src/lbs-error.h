#define LBS_ERR_SDL_INIT_FAIL                    1
#define LBS_ERR_SDL_WIN_FAIL                     2
#define LBS_ERR_SDL_RDR_FAIL                     3
#define LBS_ERR_SDL_TEX_FILE_FAIL                4
#define LBS_ERR_SDL_TEX_LOAD_FAIL                5
#define LBS_ERR_PTH_FAIL                         20