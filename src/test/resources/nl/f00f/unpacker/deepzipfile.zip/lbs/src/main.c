#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <errno.h>

#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "lbs-error.h"

#undef main

#define LBS_NUM_FOOD              12
#define LBS_NUM_FROGS             4
#define LBS_NUM_FOOD_TYPES        4

#define LBS_NORTH                 0
#define LBS_EAST                  1
#define LBS_SOUTH                 2
#define LBS_WEST                  3

#define LBS_SCREEN_WIDTH          1024
#define LBS_SCREEN_HEIGHT         768

/*******************************************************************************
 * Common division
 * Holds information shared between threads
 ******************************************************************************/

struct player {
    SDL_Texture * texture;
    SDL_Rect * location;
    SDL_Rect * colBox;
    float size;
    int weight;
    int health;
};

struct food {
    SDL_Texture * texture;
    SDL_Rect * location;
    SDL_Rect * colBox;
    int type;
    int direction;
    int bad;
};

struct frog {
    SDL_Texture * texture;
    SDL_Rect * location;
    SDL_Rect * colBox;
    int direction;
};

struct player * player;
struct food * food[LBS_NUM_FOOD];
struct frog * frogs[LBS_NUM_FROGS];

int viewportWidth = 1024;
int viewportHeight = 698;

SDL_Window * mainWindow;
SDL_Renderer * renderer;

/*******************************************************************************
 * 
 ******************************************************************************/

SDL_Texture * lbsLoadTexture(const char * filename);
void updateColBox(SDL_Rect * box, SDL_Rect * loc);

/*******************************************************************************
 * Game logic division
 * Makes everything playable
 ******************************************************************************/

void lbsInitGameLogic() {
    player = malloc(sizeof(struct player));
    player->texture = lbsLoadTexture("res/sprites/player.png");
    player->size = 4.0f;
    player->weight = 14;
    player->location = malloc(sizeof(SDL_Rect));
    player->location->x = (viewportWidth / 2) - 4;
    player->location->y = (viewportHeight / 2)  - 5;
    player->location->w = 10;
    player->location->h = 10;
    player->colBox = malloc(sizeof(SDL_Rect));
    updateColBox(player->colBox, player->location);
}

SDL_Rect * getStartingLocation(int direction) {
    SDL_Rect * loc = malloc(sizeof(SDL_Rect));
    
    loc->w = 10;
    loc->h = 10;
    
    switch(direction) {
        case LBS_NORTH:
            loc->x = abs(rand()) % viewportWidth;
            loc->y = viewportHeight;
            break;
        case LBS_EAST:
            loc->x = 0;
            loc->y = abs(rand()) % viewportHeight;
            break;
        case LBS_SOUTH:
            loc->x = abs(rand()) % viewportWidth;
            loc->y = 0;
            break;
        case LBS_WEST:
            loc->x = viewportWidth;
            loc->y = abs(rand()) % viewportHeight;
            break;
        default:
            fprintf(stderr, "Invalid direction requested: %i\n", direction);
            loc->x = 0;
            loc->y = 0;
            break;
    }
    
    return loc;
}

int updateLocation(SDL_Rect * loc, int direction) {
    switch(direction) {
        case LBS_NORTH:
            loc->y -= sqrt(player->size * 1.33f);
            break;
        case LBS_EAST:
            loc->x += sqrt(player->size * 1.33f);
            break;
        case LBS_SOUTH:
            loc->y += sqrt(player->size * 1.33f);
            break;
        case LBS_WEST:
            loc->x -= sqrt(player->size * 1.33f);
            break;
    }
    
    if(loc->x >= LBS_SCREEN_WIDTH + 10 * player->size 
       || loc->x <= -10 * player->size) return 1;
    if(loc->y >= LBS_SCREEN_HEIGHT + 10 * player->size 
       || loc->y <= -10 * player->size) return 1;
    return 0;
}

void updateColBox(SDL_Rect * box, SDL_Rect * loc) {
    box->x = loc->x - loc->w * player->size / 2;
    box->y = loc->y - loc->h * player->size / 2;
    box->w = loc->w * player->size;
    box->h = loc->h * player->size;
}

/*******************************************************************************
 * Renderer thread division
 * Displays everything
 ******************************************************************************/


SDL_Texture * lbsLoadTexture(const char * filename) {
    if(renderer == 0) {
        fprintf(stderr, "Renderer ran away!\n* What the fuck?\n");
    }
    SDL_Surface * img = IMG_Load(filename);
    if(img == 0) {
        fprintf(stderr, "Couldn't load texture (%s) from file!\n* %s\n",
                filename, SDL_GetError());
        exit(LBS_ERR_SDL_TEX_FILE_FAIL);
    }
    SDL_Texture * tex = SDL_CreateTextureFromSurface(renderer, img);
    if(tex == 0) {
        fprintf(stderr, "Couldn't process texture (%s) from file!\n* %s\n",
                filename, SDL_GetError());
        exit(LBS_ERR_SDL_TEX_LOAD_FAIL);
    }
    SDL_FreeSurface(img);
    return tex;
}

void lbsInitVideo() {
    mainWindow = SDL_CreateWindow("lbs",  
                 SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                 LBS_SCREEN_WIDTH, LBS_SCREEN_HEIGHT,
                 0
    );
    
    if(mainWindow == 0) {
        fprintf(stderr, "Couldn't create window!\n* %s\n", SDL_GetError());
        exit(LBS_ERR_SDL_WIN_FAIL);
    }
    
    renderer = SDL_CreateRenderer(mainWindow, -1, 0);
    
    if(renderer == 0) {
        fprintf(stderr, "Couldn't open renderer!\n* %s\n", SDL_GetError());
        exit(LBS_ERR_SDL_RDR_FAIL);
    }
}

/*******************************************************************************
 * Event division
 * Handles inputs in the main-thread
 ******************************************************************************/

void lbsUpdate() {
    int i, c;
    
    float weightBarWidth = 0;
    
    lbsInitVideo();
    lbsInitGameLogic();
    
    SDL_Event * e = malloc(sizeof(SDL_Event));
    
    SDL_Rect uiRect = {0, LBS_SCREEN_HEIGHT - 70, LBS_SCREEN_WIDTH, 70};
    SDL_Rect bellyRect;
    SDL_Rect segfaultRect = {
        LBS_SCREEN_WIDTH / 2 - 300,
        LBS_SCREEN_HEIGHT / 2 - 100,
        600, 200
    };
    
    SDL_Texture * segfaultTexture = lbsLoadTexture("res/sprites/segfault.png");
    
    char * typeString = malloc(24 * sizeof(char));
    
    const uint8_t * keyboardState;
    
    SDL_Rect loc;
    
    while(1) {
        if(SDL_PollEvent(e)) {
            if(e->type == SDL_QUIT) {
                break;
            }
            if(e->type == SDL_KEYDOWN) {
                if(e->key.keysym.sym == SDLK_ESCAPE) exit(0);
                else if(e->key.keysym.sym == SDLK_1) player->size += 0.03f; 
            }
        }
        
        keyboardState = SDL_GetKeyboardState(0);
        
        if(keyboardState[SDL_SCANCODE_UP]) {
            player->location->y -= player->size * 2.f;
        }
        else if(keyboardState[SDL_SCANCODE_DOWN]) {
            player->location->y += player->size * 2.f;
        }
        if(keyboardState[SDL_SCANCODE_RIGHT]) {
            player->location->x += player->size * 2.f;
        }
        else if(keyboardState[SDL_SCANCODE_LEFT]) {
            player->location->x -= player->size * 2.f;
        }
        
        player->size = (player->weight / 128.0f) + 3.0f;
        
        for(i = 0; i < LBS_NUM_FOOD; i++) {
            if(food[i] == 0) {
                food[i] = malloc(sizeof(struct food));
                food[i]->type = rand() % LBS_NUM_FOOD_TYPES;
                food[i]->direction = rand() % 4;
                food[i]->bad = rand() % 2;
                sprintf(typeString, "res/sprites/%i-%i.png",
                        food[i]->type, food[i]->bad);
                food[i]->texture = lbsLoadTexture(typeString);
                food[i]->location = getStartingLocation(food[i]->direction);
                food[i]->colBox = getStartingLocation(food[i]->direction);
                
            }
            if(updateLocation(food[i]->location, food[i]->direction)) {
                SDL_DestroyTexture(food[i]->texture);
                free(food[i]->location);
                free(food[i]);
                food[i] = 0;
            }
            else {
                updateColBox(food[i]->colBox, food[i]->location);
                if(SDL_HasIntersection(player->location, food[i]->colBox)) {
                    if(food[i]->bad) {
                        player->weight -= 1;
                    }
                    else {
                        player->weight += 1;
                    }
                    free(food[i]->location);
                    free(food[i]);
                    food[i] = 0;
                }
            }
            
        }
        
        for(i = 0; i < LBS_NUM_FROGS; i++) {
            if(frogs[i] == 0) {
                frogs[i] = malloc(sizeof(struct food));
                frogs[i]->direction = rand() % 4;
                frogs[i]->texture = lbsLoadTexture("res/sprites/frog.png");
                frogs[i]->location = getStartingLocation(frogs[i]->direction);
                frogs[i]->colBox = getStartingLocation(frogs[i]->direction);
            }
            if(updateLocation(frogs[i]->location, frogs[i]->direction)) {
                SDL_DestroyTexture(frogs[i]->texture);
                free(frogs[i]->location);
                free(frogs[i]);
                frogs[i] = 0;
            }
            else {
                updateColBox(frogs[i]->colBox, frogs[i]->location);
                if(SDL_HasIntersection(player->location, frogs[i]->colBox)) {
                    player->health -= 1;
                    free(frogs[i]->location);
                    free(frogs[i]);
                    frogs[i] = 0;
                }
            }
        }
        
        SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);
        
        SDL_RenderClear(renderer);
        
        // Present food
        for(i = 0; i < LBS_NUM_FOOD; i++) {
            if(food[i] == 0) continue;
            updateColBox(food[i]->colBox, food[i]->location);
            SDL_RenderCopy(renderer, food[i]->texture, 0, food[i]->colBox);
        }
        
        // Present frogs
        for(i = 0; i < LBS_NUM_FROGS; i++) {
            if(frogs[i] == 0) continue;
            updateColBox(frogs[i]->colBox, frogs[i]->location);
            SDL_RenderCopy(renderer, frogs[i]->texture, 0, frogs[i]->colBox);
        }
        
        updateColBox(player->colBox, player->location);
        SDL_RenderCopy(renderer, player->texture, 0, player->colBox);
        
        // Draw UI container
        
        SDL_SetRenderDrawColor(renderer, 0x10, 0x10, 0x20, 0xFF);
        SDL_RenderFillRect(renderer, &uiRect);
        
        // Draw weight bar
        
        // * Background
        
        bellyRect.x = 15;
        bellyRect.y = LBS_SCREEN_HEIGHT - 39;
        bellyRect.w = LBS_SCREEN_WIDTH - 34;
        bellyRect.h = 12;
        
        SDL_SetRenderDrawColor(renderer, 0xEF, 0xEF, 0xEF, 0xFF);
        SDL_RenderFillRect(renderer, &bellyRect);
        
        // * Bar itself
        
        bellyRect.x = 16;
        bellyRect.y += 1;
        weightBarWidth = player->weight / 64.f;
        bellyRect.w = (int)((LBS_SCREEN_WIDTH - 32) * weightBarWidth) % LBS_SCREEN_WIDTH - 32;
        bellyRect.h = 10;
        
        SDL_SetRenderDrawColor(renderer, 0xC4, 0x00, 0x00, 0xFF);
        SDL_RenderFillRect(renderer, &bellyRect);
        
        SDL_RenderPresent(renderer);
        
        SDL_Delay(16);
    }
}

/*******************************************************************************
 * Main program division
 * Bootstraps
 ******************************************************************************/

// Quit gracefully
void quit() {
    int i;
    for(i = 0; i < LBS_NUM_FOOD; i++) {
        if(food[i] != 0) {
            if(food[i]->texture != 0) SDL_DestroyTexture(food[i]->texture);
            if(food[i]->location != 0) free(food[i]->location);
            free(food[i]);
        }
    }
    for(i = 0; i < LBS_NUM_FROGS; i++) {
        if(frogs[i] != 0) {
            if(frogs[i]->texture != 0) SDL_DestroyTexture(frogs[i]->texture);
            if(frogs[i]->location != 0) free(frogs[i]->location);
            free(frogs[i]);
        }
    }
    if(player != 0) {
        if(player->location != 0) free(player->location);
        if(player->texture != 0) SDL_DestroyTexture(player->texture);
        free(player);
    }
    if(renderer != 0) SDL_DestroyRenderer(renderer);
    if(mainWindow != 0) SDL_DestroyWindow(mainWindow);
    SDL_Quit();
    exit(0);
}

int main(int argc, char ** argv) {
    int playerSprite = 0;
    
    int sysflags = SDL_INIT_TIMER | SDL_INIT_AUDIO 
                 | SDL_INIT_VIDEO | SDL_INIT_EVENTS;
    
    // TODO: add arg-based sysflags
    
    atexit(quit);
                 
    if(SDL_Init(sysflags) != 0) {
        fprintf(stderr, "Couldn't init SDL:\n* %s\n", SDL_GetError());
        exit(LBS_ERR_SDL_INIT_FAIL);
    }
    
    
    IMG_Init(IMG_INIT_PNG);
    
    // Start scanning for events
    // Returns when SDL_QUIT is detected
    lbsUpdate();
    
    return 0;
}